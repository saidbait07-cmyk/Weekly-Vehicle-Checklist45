# Smart Vehicle Inspection & Fleet Management System

A runnable, responsive Flask web platform built from the supplied starter and the scanned daily vehicle checklist. It supports Admin, Supervisor, and Driver accounts, English/Arabic/Hindi/Urdu UI, RTL for Arabic and Urdu, QR vehicle links, inspection records, fault tracking, private photo access, Excel reports, an audit log, and an offline inspection queue.

## What is included

- Employee ID and password sign-in. Passwords are hashed; there is no self-registration page or public user API.
- Admin-only account creation, role assignment, account disable/reactivate, vehicle registration, supervisor assignment, driver scheduling, checklist management, search, reports, and Excel export.
- Supervisor view limited to their assigned vehicles, inspections, faults, and reports. Supervisors can resolve faults for vehicles assigned to them.
- Driver dashboard limited to their daily vehicle assignment. A driver can have one vehicle per day, and each vehicle can have one driver per day.
- The 31 inspection rows from the attached paper checklist, including Arabic labels. The checklist labels are also translated for Hindi and Urdu. Admin can add or disable checklist items.
- Daily odometer, all checklist responses, remarks, fault records, up to six photos, and a driver confirmation.
- QR code download for a vehicle. Scanning its link opens the assigned driver's daily inspection after sign-in.
- Excel workbook with inspection, checklist, fault, employee, vehicle, and audit sheets.
- PWA shell and an offline queue for checklist answers. Open the assigned inspection once while connected; subsequent answers can be queued offline and sent when the device reconnects. Photos require a connection.

## Run locally

Requires Python 3.10 or newer.

```bash
python -m venv .venv
# Windows: .venv\\Scripts\\activate
source .venv/bin/activate
pip install -r requirements.txt
export SECRET_KEY="replace-with-a-long-random-secret"
flask --app app init-db
flask --app app create-admin
flask --app app run
```

On Windows PowerShell, set the secret with:

```powershell
$env:SECRET_KEY="replace-with-a-long-random-secret"
```

Open `http://127.0.0.1:5000`. Sign in using the Admin employee ID and password entered by `create-admin`. Then register employees from **Users**. Admin creates every account and chooses its role.

## Docker

```bash
cp .env.example .env
# Replace SECRET_KEY in .env before starting.
docker compose up --build -d
docker compose exec web flask --app app init-db
docker compose exec web flask --app app create-admin
```

The database persists in the `fleet_data` volume. Keep a private copy of the database and `private_uploads/` directory when backing up the deployment.

## Configuration

- `SECRET_KEY`: required stable secret for sessions.
- `DATABASE_URL`: defaults to a local SQLite database. Use PostgreSQL for a shared deployment.
- `APP_TIMEZONE`: defaults to `Asia/Muscat` for inspection/assignment day boundaries.
- `HTTPS=1`: enables secure session cookies when serving through HTTPS.

## Important deployment notes

This is a functional project starter, not a certified production deployment. Before a company-wide rollout, configure HTTPS, PostgreSQL, durable private photo storage and backups, login rate limits, monitoring, and a managed secret. Run it behind a production WSGI server such as Gunicorn. Existing databases from the earlier starter need a schema migration or a fresh database before using this expanded version; back up any existing data first.

Offline checklists are stored in the browser's IndexedDB and sync after reconnection when the session remains valid. Offline mode does not upload photos or authenticate a signed-out user. For shared phones, use device screen lock and sign out after use.
