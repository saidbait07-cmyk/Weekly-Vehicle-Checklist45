import io, os, secrets, json
from datetime import date, datetime, timedelta
from functools import wraps
from pathlib import Path
from zoneinfo import ZoneInfo
from flask import Flask, request, redirect, url_for, session, abort, render_template, flash, send_file, send_from_directory, jsonify
from flask_sqlalchemy import SQLAlchemy
from werkzeug.security import generate_password_hash, check_password_hash
from werkzeug.utils import secure_filename
from openpyxl import Workbook
import qrcode

BASE = Path(__file__).resolve().parent
APP_TZ = ZoneInfo(os.getenv('APP_TIMEZONE', 'Asia/Muscat'))
def today():return datetime.now(APP_TZ).date()
app = Flask(__name__)
app.config.update(
    SECRET_KEY=os.getenv('SECRET_KEY', secrets.token_hex(32)),
    SQLALCHEMY_DATABASE_URI=os.getenv('DATABASE_URL', 'sqlite:///' + str(BASE / 'fleet.db')),
    SQLALCHEMY_TRACK_MODIFICATIONS=False,
    MAX_CONTENT_LENGTH=12 * 1024 * 1024,
    SESSION_COOKIE_HTTPONLY=True,
    SESSION_COOKIE_SAMESITE='Lax',
    SESSION_COOKIE_SECURE=os.getenv('HTTPS', '0') == '1',
    PERMANENT_SESSION_LIFETIME=timedelta(days=14),
)
app.config['UPLOAD_FOLDER'] = str(BASE / 'private_uploads')
Path(app.config['UPLOAD_FOLDER']).mkdir(parents=True, exist_ok=True)
db = SQLAlchemy(app)

CHECKLIST = [
    'Light & Indicator', 'Mirrors', 'Blind spot mirror', 'Horn', 'Fuel', 'Seat Belt',
    'Communication Radio / Tape', 'A/C in Vehicle', 'Body Damage', 'Tyres, nut & bolts',
    'Load Restraint', 'Battery', 'Oil Level', 'Water Level', 'Steering',
    'Wipers & Wind Screen', 'Brakes', 'First Aid Box', 'Fire Extinguishers',
    'Jack, Tools, Triangle', 'Vehicle registration papers', 'Ladder condition', 'IVMS',
    'Housekeeping', '360 degree Walk around', 'RAS Sticker OPAL',
    "Driver's Mandatory Training Cards", 'Driver Name', 'Driver Signature',
    "Driver's ROP EXP Date", 'Supervisor / PA Signature'
]
CHECKLIST_TRANSLATIONS = {
    'ar': ['الأضواء والإشارات','المرايا','مرآة النقطة العمياء','البوق','الوقود','حزام الأمان','جهاز الاتصال / الراديو','مكيف الهواء','أضرار الهيكل','الإطارات والصواميل والبراغي','تثبيت الحمولة','البطارية','مستوى الزيت','مستوى الماء','المقود','المساحات والزجاج الأمامي','الفرامل','صندوق الإسعافات الأولية','طفايات الحريق','الرافعة والأدوات ومثلث التحذير','أوراق تسجيل المركبة','حالة السلم','نظام IVMS','نظافة المركبة','الفحص حول المركبة 360 درجة','ملصق RAS OPAL','بطاقات التدريب الإلزامي للسائق','اسم السائق','توقيع السائق','تاريخ انتهاء رخصة القيادة','توقيع المشرف / المساعد'],
    'hi': ['लाइट और इंडिकेटर','दर्पण','ब्लाइंड स्पॉट दर्पण','हॉर्न','ईंधन','सीट बेल्ट','कम्युनिकेशन रेडियो / टेप','वाहन में एसी','बॉडी क्षति','टायर, नट और बोल्ट','लोड सुरक्षा','बैटरी','ऑयल स्तर','पानी का स्तर','स्टीयरिंग','वाइपर और विंडस्क्रीन','ब्रेक','प्राथमिक चिकित्सा बॉक्स','अग्निशामक','जैक, औज़ार, त्रिकोण','वाहन पंजीकरण दस्तावेज़','सीढ़ी की स्थिति','IVMS','वाहन की सफाई','360 डिग्री वाहन जांच','RAS OPAL स्टिकर','ड्राइवर के अनिवार्य प्रशिक्षण कार्ड','ड्राइवर का नाम','ड्राइवर के हस्ताक्षर','ड्राइवर लाइसेंस समाप्ति तिथि','सुपरवाइज़र / PA हस्ताक्षर'],
    'ur': ['لائٹ اور اشارے','آئینے','بلائنڈ اسپاٹ آئینہ','ہارن','ایندھن','سیٹ بیلٹ','کمیونیکیشن ریڈیو / ٹیپ','گاڑی میں اے سی','باڈی کا نقصان','ٹائر، نٹ اور بولٹ','لوڈ کی حفاظت','بیٹری','آئل لیول','پانی کی سطح','اسٹیئرنگ','وائپر اور ونڈ اسکرین','بریک','فرسٹ ایڈ باکس','آگ بجھانے والے آلات','جیک، اوزار، مثلث','گاڑی کے رجسٹریشن کاغذات','سیڑھی کی حالت','IVMS','گاڑی کی صفائی','360 ڈگری گاڑی کا معائنہ','RAS OPAL اسٹیکر','ڈرائیور کے لازمی تربیتی کارڈ','ڈرائیور کا نام','ڈرائیور کے دستخط','ڈرائیور کے لائسنس کی میعاد','سپروائزر / PA کے دستخط']
}

TXT = {
'en': {'app':'Smart Vehicle Inspection','login':'Employee Login','employee':'Employee ID','password':'Password','remember':'Remember me','sign_in':'Sign in','dashboard':'Dashboard','users':'Users','vehicles':'Vehicles','inspections':'Inspections','faults':'Faults & Maintenance','reports':'Reports & Excel','settings':'Checklist','search':'Search','logout':'Logout','admin':'Admin Dashboard','supervisor':'Supervisor Dashboard','driver':'Driver Dashboard','register_user':'Register Employee','name':'Full name','role':'Role','initial_password':'Initial password (12+ characters)','save':'Save','status':'Status','active':'Active','inactive':'Inactive','actions':'Actions','deactivate':'Deactivate','reactivate':'Reactivate','plate':'Vehicle number / plate','type':'Vehicle type and model','supervisor':'Supervisor','add_vehicle':'Add vehicle','assign':'Assign driver','driver_user':'Driver','date':'Date','odometer':'Odometer (km)','start_km':'Starting km','end_km':'Closing km','inspection':'Daily inspection','item':'Inspection item','result':'Result','pass':'OK','fail':'Not OK','na':'N/A','remark':'Remarks / defect description','action_taken':'Action taken','photo':'Attach fault photos','submit':'Submit inspection','save_draft':'Save draft','pending':'Pending sync','synced':'Synced','today':'Today','total_vehicles':'Total vehicles','total_employees':'Total employees','today_inspections':'Inspections today','open_faults':'Open faults','recent':'Recent inspections','no_data':'No records yet','search_hint':'Search by vehicle number or employee ID','scan':'Scan vehicle QR','manual':'Or enter vehicle number','view':'View','export':'Download Excel','access_denied':'You do not have permission for this page.','created':'Account created.','saved':'Saved successfully.','vehicle_added':'Vehicle added.','assigned':'Driver assignment saved.','checklist_help':'Mark every item. Failed items create a fault record.','language':'Language','english':'English','arabic':'Arabic','hindi':'हिन्दी','urdu':'اردو','online':'Online','offline':'Offline','account_notice':'Only Admin can create or manage user accounts. There is no self-registration.','invalid_login':'Invalid Employee ID or password.','initial_admin':'Create the first administrator from the command line.','qr':'QR code','vehicle_history':'Vehicle inspection history','fault_status':'Fault status','open':'Open','closed':'Resolved','resolve':'Mark resolved','details':'Details','no_assignments':'No vehicle is assigned to you for today.','notes':'Inspection notes','license_expiry':'Driver ROP expiry date','attestation':'I confirm that I completed this check honestly.','all_items':'Checklist items','add_item':'Add checklist item','item_label':'New item label','enabled':'Enabled','disabled':'Disabled','activity':'Activity log','refresh':'Refresh','driver_name':'Driver name','supervisor_sign':'Supervisor approval','supervisor_note':'Supervisor can review and resolve faults for assigned vehicles.'},
'ar': {'app':'نظام فحص المركبات الذكي','login':'دخول الموظف','employee':'الرقم الوظيفي','password':'كلمة المرور','remember':'تذكرني','sign_in':'دخول','dashboard':'لوحة التحكم','users':'المستخدمون','vehicles':'المركبات','inspections':'الفحوصات','faults':'الأعطال والصيانة','reports':'التقارير وExcel','settings':'قائمة الفحص','search':'بحث','logout':'خروج','admin':'لوحة المسؤول','supervisor':'لوحة المشرف','driver':'لوحة السائق','register_user':'تسجيل موظف','name':'الاسم الكامل','role':'الصلاحية','initial_password':'كلمة المرور الأولية (12 حرفاً فأكثر)','save':'حفظ','status':'الحالة','active':'نشط','inactive':'موقوف','actions':'الإجراءات','deactivate':'إيقاف','reactivate':'إعادة تفعيل','plate':'رقم المركبة / اللوحة','type':'نوع المركبة والطراز','supervisor':'المشرف','add_vehicle':'إضافة مركبة','assign':'تعيين سائق','driver_user':'السائق','date':'التاريخ','odometer':'عداد المسافة (كم)','start_km':'عداد البداية','end_km':'عداد النهاية','inspection':'الفحص اليومي','item':'بند الفحص','result':'النتيجة','pass':'سليم','fail':'غير سليم','na':'لا ينطبق','remark':'الملاحظات / وصف العطل','action_taken':'الإجراء المتخذ','photo':'إرفاق صور العطل','submit':'إرسال الفحص','save_draft':'حفظ مسودة','pending':'بانتظار المزامنة','synced':'تمت المزامنة','today':'اليوم','total_vehicles':'إجمالي المركبات','total_employees':'إجمالي الموظفين','today_inspections':'فحوصات اليوم','open_faults':'الأعطال المفتوحة','recent':'أحدث الفحوصات','no_data':'لا توجد سجلات بعد','search_hint':'ابحث برقم المركبة أو الرقم الوظيفي','scan':'مسح QR المركبة','manual':'أو أدخل رقم المركبة','view':'عرض','export':'تنزيل Excel','access_denied':'ليس لديك صلاحية لهذه الصفحة.','created':'تم إنشاء الحساب.','saved':'تم الحفظ بنجاح.','vehicle_added':'تمت إضافة المركبة.','assigned':'تم حفظ تعيين السائق.','checklist_help':'أجب عن جميع البنود. البنود غير السليمة تنشئ بلاغ عطل.','language':'اللغة','english':'English','arabic':'العربية','hindi':'हिन्दी','urdu':'اردو','online':'متصل','offline':'دون اتصال','account_notice':'المسؤول فقط يمكنه إنشاء الحسابات وإدارتها. لا يوجد تسجيل ذاتي.','invalid_login':'الرقم الوظيفي أو كلمة المرور غير صحيحة.','initial_admin':'أنشئ أول حساب مسؤول من سطر الأوامر.','qr':'رمز QR','vehicle_history':'سجل فحوصات المركبة','fault_status':'حالة العطل','open':'مفتوح','closed':'تم الحل','resolve':'تحديد كمحلول','details':'التفاصيل','no_assignments':'لا توجد مركبة معيّنة لك اليوم.','notes':'ملاحظات الفحص','license_expiry':'تاريخ انتهاء رخصة القيادة','attestation':'أؤكد أنني أكملت هذا الفحص بصدق.','all_items':'بنود الفحص','add_item':'إضافة بند فحص','item_label':'اسم البند الجديد','enabled':'مفعّل','disabled':'معطّل','activity':'سجل النشاط','refresh':'تحديث','driver_name':'اسم السائق','supervisor_sign':'اعتماد المشرف','supervisor_note':'يمكن للمشرف مراجعة الأعطال وحلّها للمركبات المسندة إليه.'},
'hi': {'app':'स्मार्ट वाहन निरीक्षण','login':'कर्मचारी लॉगिन','employee':'कर्मचारी ID','password':'पासवर्ड','remember':'मुझे याद रखें','sign_in':'साइन इन','dashboard':'डैशबोर्ड','users':'उपयोगकर्ता','vehicles':'वाहन','inspections':'निरीक्षण','faults':'खराबी और रखरखाव','reports':'रिपोर्ट और Excel','settings':'चेकलिस्ट','search':'खोजें','logout':'लॉग आउट','admin':'एडमिन डैशबोर्ड','supervisor':'सुपरवाइज़र डैशबोर्ड','driver':'ड्राइवर डैशबोर्ड','register_user':'कर्मचारी पंजीकृत करें','name':'पूरा नाम','role':'भूमिका','initial_password':'प्रारंभिक पासवर्ड (12+ अक्षर)','save':'सहेजें','status':'स्थिति','active':'सक्रिय','inactive':'निष्क्रिय','actions':'कार्रवाई','deactivate':'निष्क्रिय करें','reactivate':'फिर सक्रिय करें','plate':'वाहन नंबर / प्लेट','type':'वाहन प्रकार और मॉडल','supervisor':'सुपरवाइज़र','add_vehicle':'वाहन जोड़ें','assign':'ड्राइवर असाइन करें','driver_user':'ड्राइवर','date':'तारीख','odometer':'ओडोमीटर (किमी)','start_km':'शुरुआती किमी','end_km':'अंतिम किमी','inspection':'दैनिक निरीक्षण','item':'निरीक्षण मद','result':'परिणाम','pass':'ठीक','fail':'खराब','na':'लागू नहीं','remark':'टिप्पणी / खराबी विवरण','action_taken':'की गई कार्रवाई','photo':'खराबी की फोटो जोड़ें','submit':'निरीक्षण जमा करें','save_draft':'ड्राफ्ट सहेजें','pending':'सिंक की प्रतीक्षा','synced':'सिंक हुआ','today':'आज','total_vehicles':'कुल वाहन','total_employees':'कुल कर्मचारी','today_inspections':'आज के निरीक्षण','open_faults':'खुली खराबियां','recent':'हाल के निरीक्षण','no_data':'अभी कोई रिकॉर्ड नहीं','search_hint':'वाहन नंबर या कर्मचारी ID से खोजें','scan':'वाहन QR स्कैन करें','manual':'या वाहन नंबर दर्ज करें','view':'देखें','export':'Excel डाउनलोड करें','access_denied':'आपको इस पृष्ठ की अनुमति नहीं है।','created':'खाता बनाया गया।','saved':'सफलतापूर्वक सहेजा गया।','vehicle_added':'वाहन जोड़ा गया।','assigned':'ड्राइवर असाइनमेंट सहेजा गया।','checklist_help':'हर मद का उत्तर दें। खराब मद से फॉल्ट रिकॉर्ड बनता है।','language':'भाषा','english':'English','arabic':'العربية','hindi':'हिन्दी','urdu':'اردو','online':'ऑनलाइन','offline':'ऑफ़लाइन','account_notice':'केवल Admin खाते बना और प्रबंधित कर सकता है। स्वयं पंजीकरण उपलब्ध नहीं है।','invalid_login':'गलत कर्मचारी ID या पासवर्ड।','initial_admin':'पहला Admin कमांड लाइन से बनाएं।','qr':'QR कोड','vehicle_history':'वाहन निरीक्षण इतिहास','fault_status':'खराबी स्थिति','open':'खुला','closed':'हल किया गया','resolve':'हल के रूप में चिह्नित करें','details':'विवरण','no_assignments':'आज आपको कोई वाहन असाइन नहीं है।','notes':'निरीक्षण नोट्स','license_expiry':'ड्राइवर लाइसेंस समाप्ति तिथि','attestation':'मैं पुष्टि करता/करती हूं कि मैंने यह जांच सही ढंग से की।','all_items':'चेकलिस्ट मदें','add_item':'चेकलिस्ट मद जोड़ें','item_label':'नई मद का नाम','enabled':'सक्रिय','disabled':'निष्क्रिय','activity':'गतिविधि लॉग','refresh':'रीफ्रेश','driver_name':'ड्राइवर का नाम','supervisor_sign':'सुपरवाइज़र अनुमोदन','supervisor_note':'सुपरवाइज़र असाइन किए गए वाहनों की खराबियों की समीक्षा और समाधान कर सकता है।'},
'ur': {'app':'اسمارٹ وہیکل انسپیکشن','login':'ملازم لاگ اِن','employee':'ملازم آئی ڈی','password':'پاس ورڈ','remember':'مجھے یاد رکھیں','sign_in':'سائن اِن','dashboard':'ڈیش بورڈ','users':'صارفین','vehicles':'گاڑیاں','inspections':'معائنے','faults':'خرابیاں اور مرمت','reports':'رپورٹس اور Excel','settings':'چیک لسٹ','search':'تلاش','logout':'لاگ آؤٹ','admin':'ایڈمن ڈیش بورڈ','supervisor':'سپروائزر ڈیش بورڈ','driver':'ڈرائیور ڈیش بورڈ','register_user':'ملازم درج کریں','name':'پورا نام','role':'کردار','initial_password':'ابتدائی پاس ورڈ (12+ حروف)','save':'محفوظ کریں','status':'حالت','active':'فعال','inactive':'غیر فعال','actions':'عمل','deactivate':'غیر فعال کریں','reactivate':'دوبارہ فعال کریں','plate':'گاڑی نمبر / پلیٹ','type':'گاڑی کی قسم اور ماڈل','supervisor':'سپروائزر','add_vehicle':'گاڑی شامل کریں','assign':'ڈرائیور مقرر کریں','driver_user':'ڈرائیور','date':'تاریخ','odometer':'اوڈومیٹر (کلومیٹر)','start_km':'ابتدائی کلومیٹر','end_km':'اختتامی کلومیٹر','inspection':'روزانہ معائنہ','item':'معائنے کا آئٹم','result':'نتیجہ','pass':'درست','fail':'خراب','na':'لاگو نہیں','remark':'تبصرے / خرابی کی تفصیل','action_taken':'کی گئی کارروائی','photo':'خرابی کی تصاویر لگائیں','submit':'معائنہ جمع کریں','save_draft':'ڈرافٹ محفوظ کریں','pending':'سنک کا انتظار','synced':'سنک ہو گیا','today':'آج','total_vehicles':'کل گاڑیاں','total_employees':'کل ملازمین','today_inspections':'آج کے معائنے','open_faults':'کھلی خرابیاں','recent':'حالیہ معائنے','no_data':'ابھی کوئی ریکارڈ نہیں','search_hint':'گاڑی نمبر یا ملازم آئی ڈی تلاش کریں','scan':'گاڑی کا QR اسکین کریں','manual':'یا گاڑی نمبر درج کریں','view':'دیکھیں','export':'Excel ڈاؤن لوڈ کریں','access_denied':'آپ کو اس صفحے کی اجازت نہیں۔','created':'اکاؤنٹ بن گیا۔','saved':'کامیابی سے محفوظ ہوا۔','vehicle_added':'گاڑی شامل ہو گئی۔','assigned':'ڈرائیور کی تعیناتی محفوظ ہو گئی۔','checklist_help':'ہر آئٹم کا جواب دیں۔ خراب آئٹم سے فالٹ ریکارڈ بنتا ہے۔','language':'زبان','english':'English','arabic':'العربية','hindi':'हिन्दी','urdu':'اردو','online':'آن لائن','offline':'آف لائن','account_notice':'صرف Admin اکاؤنٹس بنا اور منظم کر سکتا ہے۔ خود اندراج موجود نہیں۔','invalid_login':'غلط ملازم آئی ڈی یا پاس ورڈ۔','initial_admin':'پہلا Admin کمانڈ لائن سے بنائیں۔','qr':'QR کوڈ','vehicle_history':'گاڑی کے معائنے کی تاریخ','fault_status':'خرابی کی حالت','open':'کھلی','closed':'حل شدہ','resolve':'حل شدہ نشان زد کریں','details':'تفصیلات','no_assignments':'آج آپ کو کوئی گاڑی مقرر نہیں ہے۔','notes':'معائنے کے نوٹس','license_expiry':'ڈرائیور لائسنس کی میعاد','attestation':'میں تصدیق کرتا/کرتی ہوں کہ میں نے یہ معائنہ درست کیا۔','all_items':'چیک لسٹ آئٹمز','add_item':'چیک لسٹ آئٹم شامل کریں','item_label':'نئے آئٹم کا نام','enabled':'فعال','disabled':'غیر فعال','activity':'سرگرمی لاگ','refresh':'تازہ کریں','driver_name':'ڈرائیور کا نام','supervisor_sign':'سپروائزر کی منظوری','supervisor_note':'سپروائزر مقررہ گاڑیوں کی خرابیوں کا جائزہ اور حل کر سکتا ہے۔'}
}

for _language, _words in {
    'en': {'assign':'Assign driver','quick_actions':'Quick actions'},
    'ar': {'assign':'تعيين سائق','quick_actions':'إجراءات سريعة'},
    'hi': {'assign':'ड्राइवर असाइन करें','quick_actions':'त्वरित कार्रवाई'},
    'ur': {'assign':'ڈرائیور مقرر کریں','quick_actions':'فوری کارروائیاں'},
}.items():
    TXT[_language].update(_words)
for _language, _words in {
    'en': {'pending_approval':'Pending supervisor approval','approved':'Approved','approve':'Approve'},
    'ar': {'pending_approval':'بانتظار اعتماد المشرف','approved':'معتمد','approve':'اعتماد'},
    'hi': {'pending_approval':'सुपरवाइज़र की मंजूरी लंबित','approved':'मंजूर','approve':'मंजूर करें'},
    'ur': {'pending_approval':'سپروائزر کی منظوری زیرِ التوا','approved':'منظور شدہ','approve':'منظور کریں'},
}.items():
    TXT[_language].update(_words)

XL = {
    'en': ['Inspections','Checklist','Faults','Employees','Vehicles','Audit','ID','Inspection ID','Date','Vehicle','Employee ID','Driver','Starting KM','Closing KM','Status','Notes','Item','Result','Remark','Fault ID','Description','Action Taken','Role','Type','Actor','Event','Timestamp'],
    'ar': ['الفحوصات','قائمة الفحص','الأعطال','الموظفون','المركبات','سجل النشاط','المعرّف','رقم الفحص','التاريخ','المركبة','الرقم الوظيفي','السائق','عداد البداية','عداد النهاية','الحالة','ملاحظات','البند','النتيجة','ملاحظة','رقم العطل','الوصف','الإجراء المتخذ','الصلاحية','النوع','المستخدم','الحدث','الوقت'],
    'hi': ['निरीक्षण','चेकलिस्ट','खराबियां','कर्मचारी','वाहन','ऑडिट','ID','निरीक्षण ID','तारीख','वाहन','कर्मचारी ID','ड्राइवर','शुरुआती KM','अंतिम KM','स्थिति','नोट्स','मद','परिणाम','टिप्पणी','खराबी ID','विवरण','की गई कार्रवाई','भूमिका','प्रकार','उपयोगकर्ता','घटना','समय'],
    'ur': ['معائنے','چیک لسٹ','خرابیاں','ملازمین','گاڑیاں','آڈٹ','ID','معائنہ ID','تاریخ','گاڑی','ملازم ID','ڈرائیور','ابتدائی KM','اختتامی KM','حالت','نوٹس','آئٹم','نتیجہ','تبصرہ','خرابی ID','تفصیل','کی گئی کارروائی','کردار','قسم','صارف','واقعہ','وقت']
}

class User(db.Model):
    id=db.Column(db.Integer,primary_key=True)
    employee_id=db.Column(db.String(50),unique=True,nullable=False)
    name=db.Column(db.String(120),nullable=False)
    password_hash=db.Column(db.String(255),nullable=False)
    role=db.Column(db.String(20),nullable=False)
    active=db.Column(db.Boolean,default=True,nullable=False)
    language=db.Column(db.String(5),default='en')

class Vehicle(db.Model):
    id=db.Column(db.Integer,primary_key=True)
    plate=db.Column(db.String(50),unique=True,nullable=False)
    description=db.Column(db.String(200),default='')
    vehicle_type=db.Column(db.String(80),default='')
    supervisor_id=db.Column(db.Integer,db.ForeignKey('user.id'))
    qr_token=db.Column(db.String(48),unique=True,default=lambda:secrets.token_urlsafe(24))

class Assignment(db.Model):
    id=db.Column(db.Integer,primary_key=True)
    vehicle_id=db.Column(db.Integer,db.ForeignKey('vehicle.id'),nullable=False)
    driver_id=db.Column(db.Integer,db.ForeignKey('user.id'),nullable=False)
    day=db.Column(db.Date,nullable=False)
    __table_args__=(db.UniqueConstraint('vehicle_id','day',name='one_driver_per_vehicle_per_day'),db.UniqueConstraint('driver_id','day',name='one_vehicle_per_driver_per_day'))

class Item(db.Model):
    id=db.Column(db.Integer,primary_key=True)
    label=db.Column(db.String(250),nullable=False)
    active=db.Column(db.Boolean,default=True,nullable=False)
    order=db.Column(db.Integer,default=0)
    label_ar=db.Column(db.String(250),default='')
    label_hi=db.Column(db.String(250),default='')
    label_ur=db.Column(db.String(250),default='')

class Inspection(db.Model):
    id=db.Column(db.Integer,primary_key=True)
    vehicle_id=db.Column(db.Integer,db.ForeignKey('vehicle.id'),nullable=False)
    driver_id=db.Column(db.Integer,db.ForeignKey('user.id'),nullable=False)
    day=db.Column(db.Date,nullable=False)
    odometer=db.Column(db.Integer,nullable=False)
    start_km=db.Column(db.Integer,default=0)
    notes=db.Column(db.Text,default='')
    driver_signature=db.Column(db.String(120),default='')
    license_expiry=db.Column(db.Date)
    status=db.Column(db.String(16),default='pending_approval')
    supervisor_approved_by=db.Column(db.Integer,db.ForeignKey('user.id'))
    supervisor_approved_at=db.Column(db.DateTime)
    created_at=db.Column(db.DateTime,default=datetime.utcnow)
    __table_args__=(db.UniqueConstraint('vehicle_id','day',name='one_inspection_per_vehicle_per_day'),)

class Answer(db.Model):
    id=db.Column(db.Integer,primary_key=True)
    inspection_id=db.Column(db.Integer,db.ForeignKey('inspection.id'),nullable=False)
    item_id=db.Column(db.Integer,db.ForeignKey('item.id'))
    label_snapshot=db.Column(db.String(250),nullable=False)
    result=db.Column(db.String(10),nullable=False)
    remark=db.Column(db.Text,default='')

class Fault(db.Model):
    id=db.Column(db.Integer,primary_key=True)
    inspection_id=db.Column(db.Integer,db.ForeignKey('inspection.id'),nullable=False)
    answer_id=db.Column(db.Integer,db.ForeignKey('answer.id'),nullable=False)
    description=db.Column(db.Text,nullable=False)
    action_taken=db.Column(db.Text,default='')
    status=db.Column(db.String(16),default='open')
    resolved_by=db.Column(db.Integer,db.ForeignKey('user.id'))
    resolved_at=db.Column(db.DateTime)

class Photo(db.Model):
    id=db.Column(db.Integer,primary_key=True)
    fault_id=db.Column(db.Integer,db.ForeignKey('fault.id'),nullable=False)
    filename=db.Column(db.String(255),nullable=False)
    original_name=db.Column(db.String(255),default='')

class Audit(db.Model):
    id=db.Column(db.Integer,primary_key=True)
    actor_id=db.Column(db.Integer,db.ForeignKey('user.id'))
    actor_employee_id=db.Column(db.String(50),default='system')
    event=db.Column(db.String(250),nullable=False)
    at=db.Column(db.DateTime,default=datetime.utcnow)


def current_user():
    uid=session.get('uid')
    return db.session.get(User,uid) if uid else None

def tr(key):
    u=current_user(); lang=(session.get('lang') or (u.language if u else 'en'))
    return TXT.get(lang,TXT['en']).get(key,TXT['en'].get(key,key))

def xl(index):
    lang=session.get('lang') or (current_user().language if current_user() else 'en')
    return XL.get(lang,XL['en'])[index]

def item_name(item):
    lang=session.get('lang') or (current_user().language if current_user() else 'en')
    return getattr(item,'label_'+lang,'') or item.label

@app.context_processor
def inject():
    u=current_user();lang=session.get('lang') or (u.language if u else 'en')
    return {'t':tr,'user':u,'lang':lang,'rtl':lang in ('ar','ur'),'csrf_token':csrf_token,'today':today,'Fault':Fault,'item_name':item_name}

def csrf_token():
    if 'csrf' not in session:session['csrf']=secrets.token_urlsafe(32)
    return session['csrf']

def verify_csrf():
    if not secrets.compare_digest(request.form.get('csrf',''),session.get('csrf','')):abort(400)

def login_required(*roles):
    def deco(fn):
        @wraps(fn)
        def wrapper(*a,**kw):
            u=current_user()
            if not u or not u.active:return redirect(url_for('login'))
            if roles and u.role not in roles:abort(403)
            return fn(*a,**kw)
        return wrapper
    return deco

def log(event):
    u=current_user();db.session.add(Audit(actor_id=u.id if u else None,actor_employee_id=u.employee_id if u else 'system',event=event))

def page(title,body,**data):
    return render_template('page.html',title=title,body=body,**data)

def allowed_vehicle(vehicle_id,u=None):
    u=u or current_user()
    if u.role=='admin':return True
    if u.role=='supervisor':return Vehicle.query.filter_by(id=vehicle_id,supervisor_id=u.id).first() is not None
    return Assignment.query.filter_by(vehicle_id=vehicle_id,driver_id=u.id).first() is not None or Inspection.query.filter_by(vehicle_id=vehicle_id,driver_id=u.id).first() is not None

@app.route('/')
def home():return redirect(url_for('dashboard' if current_user() else 'login'))

@app.route('/language/<lang>')
def language(lang):
    if lang not in TXT:abort(404)
    session['lang']=lang
    u=current_user()
    if u:u.language=lang;db.session.commit()
    return redirect(request.referrer or url_for('dashboard' if u else 'login'))

@app.route('/login',methods=['GET','POST'])
def login():
    if request.method=='POST':
        verify_csrf();eid=request.form.get('employee_id','').strip();pw=request.form.get('password','')
        u=User.query.filter_by(employee_id=eid).first()
        if u and u.active and check_password_hash(u.password_hash,pw):
            session.clear();session['uid']=u.id;session['lang']=u.language or 'en';csrf_token()
            if request.form.get('remember'):session.permanent=True
            log('Signed in');db.session.commit();return redirect(url_for('dashboard'))
        flash(tr('invalid_login'),'error')
    return page(tr('login'),render_template('login.html'))

@app.route('/logout',methods=['POST'])
def logout():
    verify_csrf();log('Signed out');db.session.commit();session.clear();return redirect(url_for('login'))

@app.route('/dashboard')
@login_required()
def dashboard():
    u=current_user()
    if u.role=='admin':
        today_inspections=Inspection.query.filter_by(day=today()).count();assigned=Assignment.query.filter_by(day=today()).count()
        passed=Answer.query.join(Inspection).filter(Inspection.day==today(),Answer.result=='pass').count();failed=Answer.query.join(Inspection).filter(Inspection.day==today(),Answer.result=='fail').count()
        content=render_template('admin_dashboard.html',users=User.query.count(),vehicles=Vehicle.query.count(),inspections=today_inspections,faults=Fault.query.filter_by(status='open').count(),recent=Inspection.query.order_by(Inspection.created_at.desc()).limit(8).all(),plates={v.id:v.plate for v in Vehicle.query.all()},names={x.id:x.name for x in User.query.all()},passed=passed,failed=failed,pending=max(0,assigned-today_inspections))
        return page(tr('admin'),content)
    if u.role=='supervisor':
        vs=Vehicle.query.filter_by(supervisor_id=u.id).all();ids=[v.id for v in vs]
        recent=Inspection.query.filter(Inspection.vehicle_id.in_(ids)).order_by(Inspection.created_at.desc()).limit(10).all() if ids else []
        return page(tr('supervisor'),render_template('supervisor_dashboard.html',vehicles=vs,recent=recent,plates={v.id:v.plate for v in vs},names={x.id:x.name for x in User.query.all()},faults=Fault.query.join(Inspection).filter(Inspection.vehicle_id.in_(ids),Fault.status=='open').count() if ids else 0))
    assignments=Assignment.query.filter_by(driver_id=u.id,day=today()).all()
    return page(tr('driver'),render_template('driver_dashboard.html',assignments=assignments,vehicles={a.vehicle_id:db.session.get(Vehicle,a.vehicle_id) for a in assignments}))

@app.route('/admin/users',methods=['GET','POST'])
@login_required('admin')
def users():
    if request.method=='POST':
        verify_csrf();action=request.form.get('action')
        if action=='toggle':
            person=db.session.get(User,int(request.form.get('user_id','0')))
            if person:
                if person.id==current_user().id and person.active:flash('You cannot deactivate your own active Admin account.','error')
                else:person.active=not person.active;log(('Activated ' if person.active else 'Deactivated ')+'user '+person.employee_id);db.session.commit();flash(tr('saved'),'success')
            return redirect(url_for('users'))
        eid=request.form.get('employee_id','').strip();name=request.form.get('name','').strip();pw=request.form.get('password','');role=request.form.get('role','')
        if not eid or not name or len(pw)<12 or role not in ('admin','supervisor','driver'):flash('Enter valid details. Password must be at least 12 characters.','error')
        elif User.query.filter_by(employee_id=eid).first():flash('Employee ID already exists.','error')
        else:db.session.add(User(employee_id=eid,name=name,password_hash=generate_password_hash(pw),role=role));log('Created user '+eid);db.session.commit();flash(tr('created'),'success');return redirect(url_for('users'))
    return page(tr('users'),render_template('users.html',people=User.query.order_by(User.id).all()))

@app.route('/admin/vehicles',methods=['GET','POST'])
@login_required('admin')
def vehicles():
    if request.method=='POST':
        verify_csrf();plate=request.form.get('plate','').strip()
        if not plate:flash('Vehicle number is required.','error')
        elif Vehicle.query.filter_by(plate=plate).first():flash('Vehicle already exists.','error')
        else:
            sid=request.form.get('supervisor_id');db.session.add(Vehicle(plate=plate,description=request.form.get('description','').strip(),vehicle_type=request.form.get('vehicle_type','').strip(),supervisor_id=int(sid) if sid else None));log('Registered vehicle '+plate);db.session.commit();flash(tr('vehicle_added'),'success');return redirect(url_for('vehicles'))
    return page(tr('vehicles'),render_template('vehicles.html',vehicles=Vehicle.query.order_by(Vehicle.plate).all(),supervisors=User.query.filter_by(role='supervisor',active=True).all()))

@app.route('/admin/assign',methods=['GET','POST'])
@login_required('admin')
def assign():
    if request.method=='POST':
        verify_csrf();vid=int(request.form['vehicle_id']);did=int(request.form['driver_id']);day=date.fromisoformat(request.form['day']);driver=db.session.get(User,did)
        if not driver or driver.role!='driver' or not driver.active:abort(400)
        if Assignment.query.filter(Assignment.driver_id==did,Assignment.day==day,Assignment.vehicle_id!=vid).first():flash('This driver already has a vehicle assigned on that date.','error')
        else:
            a=Assignment.query.filter_by(vehicle_id=vid,day=day).first()
            if a:a.driver_id=did
            else:db.session.add(Assignment(vehicle_id=vid,driver_id=did,day=day))
            log(f'Assigned vehicle {vid} to driver {did} on {day}');db.session.commit();flash(tr('assigned'),'success');return redirect(url_for('assign'))
    return page(tr('assign'),render_template('assign.html',vehicles=Vehicle.query.all(),drivers=User.query.filter_by(role='driver',active=True).all(),today=today().isoformat()))

@app.route('/admin/checklist',methods=['GET','POST'])
@login_required('admin')
def checklist():
    if request.method=='POST':
        verify_csrf();action=request.form.get('action')
        if action=='add':
            label=request.form.get('label','').strip()
            if label:db.session.add(Item(label=label,order=(db.session.query(db.func.max(Item.order)).scalar() or 0)+1));log('Added checklist item '+label)
        else:
            item=db.session.get(Item,int(request.form.get('item_id','0')))
            if item and 28<=item.order<=31:flash('The driver and supervisor sign-off fields are required and cannot be disabled.','error')
            elif item:item.active=not item.active;log('Toggled checklist item '+str(item.id))
        db.session.commit();return redirect(url_for('checklist'))
    return page(tr('settings'),render_template('checklist.html',items=Item.query.order_by(Item.order,Item.id).all()))

@app.route('/vehicle/<int:vid>')
@login_required()
def vehicle_detail(vid):
    v=db.get_or_404(Vehicle,vid);u=current_user()
    if not allowed_vehicle(vid,u):abort(403)
    records=Inspection.query.filter_by(vehicle_id=vid).order_by(Inspection.day.desc()).all()
    return page(v.plate,render_template('vehicle_detail.html',vehicle=v,records=records,names={r.driver_id:db.session.get(User,r.driver_id).name for r in records}))

@app.route('/vehicle/<int:vid>/qr.png')
@login_required('admin','supervisor')
def vehicle_qr(vid):
    v=db.get_or_404(Vehicle,vid)
    if not allowed_vehicle(vid):abort(403)
    img=qrcode.make(url_for('scan_vehicle',token=v.qr_token,_external=True));out=io.BytesIO();img.save(out,format='PNG');out.seek(0)
    return send_file(out,mimetype='image/png',download_name=secure_filename(v.plate)+'-qr.png')

@app.route('/scan/<token>')
@login_required()
def scan_vehicle(token):
    v=Vehicle.query.filter_by(qr_token=token).first_or_404()
    if current_user().role!='driver':return redirect(url_for('vehicle_detail',vid=v.id))
    if not Assignment.query.filter_by(vehicle_id=v.id,driver_id=current_user().id,day=today()).first():abort(403)
    return redirect(url_for('inspect',vid=v.id))

@app.route('/inspect/<int:vid>',methods=['GET','POST'])
@login_required('driver')
def inspect(vid):
    v=db.get_or_404(Vehicle,vid);u=current_user();inspection_day=today()
    if not Assignment.query.filter_by(vehicle_id=vid,driver_id=u.id,day=inspection_day).first():abort(403)
    existing=Inspection.query.filter_by(vehicle_id=vid,day=inspection_day).first()
    if existing:return page(tr('inspection'),'<section class="panel"><h2>Inspection already submitted today</h2><a class="button" href="'+url_for('vehicle_detail',vid=vid)+'">'+tr('view')+'</a></section>')
    items=Item.query.filter_by(active=True).order_by(Item.order,Item.id).all()
    check_items=[item for item in items if item.order<=27 or item.order>=32]
    if request.method=='POST':
        verify_csrf()
        try:start=int(request.form.get('start_km','0'));odo=int(request.form['odometer']);assert start>=0 and odo>=start
        except (ValueError,AssertionError):abort(400)
        answers={str(i.id):request.form.get('item_'+str(i.id)) for i in check_items}
        try:license_expiry=date.fromisoformat(request.form.get('license_expiry',''))
        except ValueError:license_expiry=None
        signature=request.form.get('driver_signature','').strip()
        if not check_items or any(val not in ('pass','fail','na') for val in answers.values()):flash('Answer all checklist items.','error')
        elif not signature or not license_expiry:flash('Enter driver signature and license expiry date.','error')
        elif not request.form.get('attestation'):flash('Please confirm the checklist.','error')
        else:
            rec=Inspection(vehicle_id=vid,driver_id=u.id,day=inspection_day,odometer=odo,start_km=start,driver_signature=signature,license_expiry=license_expiry,notes=request.form.get('notes','').strip());db.session.add(rec);db.session.flush();fail_answer_ids=[]
            for item in check_items:
                ans=Answer(inspection_id=rec.id,item_id=item.id,label_snapshot=item_name(item),result=answers[str(item.id)],remark=request.form.get('remark_'+str(item.id),'').strip());db.session.add(ans);db.session.flush()
                if ans.result=='fail':
                    fault=Fault(inspection_id=rec.id,answer_id=ans.id,description=ans.remark or item.label);db.session.add(fault);db.session.flush();fail_answer_ids.append((ans.id,fault.id))
            db.session.flush()
            files=request.files.getlist('photos')
            if len([f for f in files if f and f.filename])>6:abort(400)
            for f in files:
                if not f or not f.filename:continue
                ext=Path(f.filename).suffix.lower()
                if ext not in ('.jpg','.jpeg','.png','.webp'):continue
                fid=fail_answer_ids[0][1] if fail_answer_ids else None
                if fid:
                    name=secrets.token_hex(16)+ext;f.save(os.path.join(app.config['UPLOAD_FOLDER'],name));db.session.add(Photo(fault_id=fid,filename=name,original_name=secure_filename(f.filename)))
            log('Submitted inspection '+str(rec.id));db.session.commit();flash(tr('saved'),'success');return redirect(url_for('vehicle_detail',vid=vid))
    return page(tr('inspection'),render_template('inspect.html',vehicle=v,items=items,today=inspection_day.isoformat()))

@app.route('/faults')
@login_required()
def faults():
    u=current_user();q=Fault.query.join(Inspection)
    if u.role=='supervisor':q=q.filter(Inspection.vehicle_id.in_([v.id for v in Vehicle.query.filter_by(supervisor_id=u.id).all()]))
    elif u.role=='driver':q=q.filter(Inspection.driver_id==u.id)
    rows=q.order_by(Fault.status,Fault.id.desc()).all()
    return page(tr('faults'),render_template('faults.html',faults=rows,vehicles={v.id:v.plate for v in Vehicle.query.all()},inspections={i.id:i for i in Inspection.query.all()},answers={a.id:a for a in Answer.query.all()},photos={f.id:Photo.query.filter_by(fault_id=f.id).all() for f in rows}))

@app.route('/fault-photo/<filename>')
@login_required()
def fault_photo(filename):
    photo=Photo.query.filter_by(filename=filename).first_or_404();fault=db.session.get(Fault,photo.fault_id);inspection=db.session.get(Inspection,fault.inspection_id)
    u=current_user()
    if u.role=='driver' and inspection.driver_id!=u.id:abort(403)
    if u.role=='supervisor' and not allowed_vehicle(inspection.vehicle_id,u):abort(403)
    return send_from_directory(app.config['UPLOAD_FOLDER'],photo.filename,as_attachment=False)

@app.route('/fault/<int:fid>/resolve',methods=['POST'])
@login_required('admin','supervisor')
def resolve_fault(fid):
    verify_csrf();f=db.get_or_404(Fault,fid);i=db.session.get(Inspection,f.inspection_id)
    if not allowed_vehicle(i.vehicle_id):abort(403)
    f.status='resolved';f.action_taken=request.form.get('action_taken','').strip();f.resolved_by=current_user().id;f.resolved_at=datetime.utcnow();log('Resolved fault '+str(fid));db.session.commit();flash(tr('saved'),'success');return redirect(url_for('faults'))

@app.route('/search')
@login_required()
def search():
    q=request.args.get('q','').strip();u=current_user();vs=[];people=[]
    if q:
        query=Vehicle.query.filter(Vehicle.plate.ilike('%'+q+'%'))
        if u.role=='supervisor':query=query.filter_by(supervisor_id=u.id)
        if u.role=='driver':query=query.filter(Vehicle.id.in_([a.vehicle_id for a in Assignment.query.filter_by(driver_id=u.id).all()]))
        vs=query.all()
        if u.role=='admin':people=User.query.filter((User.employee_id.ilike('%'+q+'%'))|(User.name.ilike('%'+q+'%'))).all()
    return page(tr('search'),render_template('search.html',q=q,vehicles=vs,people=people))

@app.route('/reports')
@login_required('admin','supervisor')
def reports():
    u=current_user();query=Inspection.query
    if u.role=='supervisor':query=query.filter(Inspection.vehicle_id.in_([v.id for v in Vehicle.query.filter_by(supervisor_id=u.id).all()]))
    records=query.order_by(Inspection.day.desc()).limit(500).all()
    return page(tr('reports'),render_template('reports.html',records=records,vehicles={v.id:v.plate for v in Vehicle.query.all()},names={p.id:p.name for p in User.query.all()}))

@app.route('/inspection/<int:iid>/approve',methods=['POST'])
@login_required('supervisor')
def approve_inspection(iid):
    verify_csrf();rec=db.get_or_404(Inspection,iid)
    if not allowed_vehicle(rec.vehicle_id):abort(403)
    rec.status='approved';rec.supervisor_approved_by=current_user().id;rec.supervisor_approved_at=datetime.utcnow();log('Approved inspection '+str(rec.id));db.session.commit();flash(tr('saved'),'success');return redirect(request.referrer or url_for('reports'))

@app.route('/admin/export.xlsx')
@login_required('admin','supervisor')
def export():
    u=current_user();ids=None
    if u.role=='supervisor':ids=[v.id for v in Vehicle.query.filter_by(supervisor_id=u.id).all()]
    q=Inspection.query
    if ids is not None:q=q.filter(Inspection.vehicle_id.in_(ids))
    records=q.order_by(Inspection.id).all();wb=Workbook();ws=wb.active;ws.title=xl(0);ws.append([xl(7),xl(8),xl(9),xl(10),xl(11),xl(12),xl(13),xl(14),xl(15),tr('license_expiry'),tr('driver_name'),tr('supervisor_sign')])
    for r in records:
        ws.append([r.id,str(r.day),db.session.get(Vehicle,r.vehicle_id).plate,db.session.get(User,r.driver_id).employee_id,db.session.get(User,r.driver_id).name,r.start_km,r.odometer,tr('approved') if r.status=='approved' else tr('pending_approval'),r.notes,str(r.license_expiry or ''),r.driver_signature,db.session.get(User,r.supervisor_approved_by).name if r.supervisor_approved_by else ''])
    ws=wb.create_sheet(xl(1));ws.append([xl(7),xl(9),xl(11),xl(8),xl(16),xl(17),xl(18)])
    for r in records:
        for a in Answer.query.filter_by(inspection_id=r.id).all():ws.append([r.id,db.session.get(Vehicle,r.vehicle_id).plate,db.session.get(User,r.driver_id).name,str(r.day),a.label_snapshot,tr(a.result),a.remark])
    ws=wb.create_sheet(xl(2));ws.append([xl(19),xl(7),xl(9),xl(20),xl(21),xl(14)])
    fq=Fault.query.join(Inspection)
    if ids is not None:fq=fq.filter(Inspection.vehicle_id.in_(ids))
    for f in fq.all():ws.append([f.id,f.inspection_id,db.session.get(Vehicle,db.session.get(Inspection,f.inspection_id).vehicle_id).plate,f.description,f.action_taken,tr('open') if f.status=='open' else tr('closed')])
    ws=wb.create_sheet(xl(3));ws.append([xl(10),tr('name'),xl(22),xl(14)])
    for p in User.query.all():ws.append([p.employee_id,p.name,p.role,tr('active') if p.active else tr('inactive')])
    ws=wb.create_sheet(xl(4));ws.append([xl(9),xl(23),xl(20)])
    for v in Vehicle.query.all():ws.append([v.plate,v.vehicle_type,v.description])
    ws=wb.create_sheet(xl(5));ws.append([xl(24),xl(25),xl(26)])
    for a in Audit.query.order_by(Audit.at).all():ws.append([a.actor_employee_id,a.event,str(a.at)])
    log('Exported Excel');db.session.commit();out=io.BytesIO();wb.save(out);out.seek(0)
    return send_file(out,as_attachment=True,download_name='vehicle_inspections_'+today().isoformat()+'.xlsx',mimetype='application/vnd.openxmlformats-officedocument.spreadsheetml.sheet')

@app.route('/api/inspections',methods=['POST'])
@login_required('driver')
def sync_inspection():
    # JSON queue endpoint for the PWA; it still enforces today's driver assignment.
    if not secrets.compare_digest(request.headers.get('X-CSRF-Token',''),session.get('csrf','')):abort(400)
    payload=request.get_json(silent=True) or {};vid=int(payload.get('vehicle_id',0));u=current_user()
    if not Assignment.query.filter_by(vehicle_id=vid,driver_id=u.id,day=today()).first():abort(403)
    existing=Inspection.query.filter_by(vehicle_id=vid,day=today()).first()
    if existing:return jsonify({'ok':True,'inspection_id':existing.id,'duplicate':True})
    active=Item.query.filter_by(active=True).order_by(Item.order,Item.id).all();check_items=[i for i in active if i.order<=27 or i.order>=32];answers=payload.get('answers',{})
    if not check_items or any(answers.get(str(i.id)) not in ('pass','fail','na') for i in check_items):return jsonify({'ok':False,'error':'incomplete_checklist'}),400
    if not payload.get('attestation'):return jsonify({'ok':False,'error':'confirmation_required'}),400
    signature=str(payload.get('driver_signature','')).strip()
    try:license_expiry=date.fromisoformat(payload.get('license_expiry',''))
    except (ValueError,TypeError):return jsonify({'ok':False,'error':'license_expiry_required'}),400
    if not signature:return jsonify({'ok':False,'error':'signature_required'}),400
    try:start=int(payload.get('start_km',0));odo=int(payload['odometer'])
    except (ValueError,KeyError,TypeError):return jsonify({'ok':False,'error':'invalid_odometer'}),400
    if start<0 or odo<start:return jsonify({'ok':False,'error':'invalid_odometer'}),400
    rec=Inspection(vehicle_id=vid,driver_id=u.id,day=today(),odometer=odo,start_km=start,driver_signature=signature,license_expiry=license_expiry,notes=payload.get('notes',''));db.session.add(rec);db.session.flush()
    for item in check_items:
        result=answers[str(item.id)];ans=Answer(inspection_id=rec.id,item_id=item.id,label_snapshot=item_name(item),result=result,remark=payload.get('remarks',{}).get(str(item.id),''));db.session.add(ans);db.session.flush()
        if result=='fail':db.session.add(Fault(inspection_id=rec.id,answer_id=ans.id,description=ans.remark or item.label))
    log('Synced offline inspection '+str(rec.id));db.session.commit();return jsonify({'ok':True,'inspection_id':rec.id})

@app.route('/manifest.webmanifest')
def manifest():return app.send_static_file('manifest.webmanifest')

@app.route('/sw.js')
def service_worker():
    response=app.send_static_file('sw.js');response.headers['Service-Worker-Allowed']='/';return response

@app.errorhandler(403)
def forbidden(e):return page('403','<section class="panel"><h2>'+tr('access_denied')+'</h2><a class="button" href="'+url_for('dashboard')+'">'+tr('dashboard')+'</a></section>'),403

@app.cli.command('init-db')
def init_db():
    db.create_all()
    if Item.query.count()==0:
        for n,label in enumerate(CHECKLIST,1):
            db.session.add(Item(label=label,order=n,label_ar=CHECKLIST_TRANSLATIONS['ar'][n-1],label_hi=CHECKLIST_TRANSLATIONS['hi'][n-1],label_ur=CHECKLIST_TRANSLATIONS['ur'][n-1]))
    db.session.commit();print('Database initialized with the 31 checklist rows from the scanned paper form.')

@app.cli.command('create-admin')
def create_admin():
    import getpass
    eid=input('Admin employee ID: ').strip();name=input('Admin full name: ').strip();pw=getpass.getpass('Admin password (12+ characters): ')
    if len(pw)<12:raise ValueError('Password must be at least 12 characters')
    if User.query.filter_by(employee_id=eid).first():raise ValueError('Employee ID exists')
    db.session.add(User(employee_id=eid,name=name,password_hash=generate_password_hash(pw),role='admin',language='en'));db.session.commit();print('Admin created')

if __name__=='__main__':app.run(debug=False)
