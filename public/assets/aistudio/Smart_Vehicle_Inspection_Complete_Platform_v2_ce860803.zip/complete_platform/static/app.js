(() => {
  const connection = document.getElementById('connection');
  const offlineBadge = document.getElementById('offline-indicator');
  const updateNetwork = () => {
    const online = navigator.onLine;
    if (connection) {
      connection.textContent = `● ${online ? 'Online' : 'Offline'}`;
      connection.style.color = online ? '#bfead7' : '#ffd387';
    }
    if (offlineBadge) {
      offlineBadge.textContent = online ? 'Online' : 'Offline';
      offlineBadge.className = `badge ${online ? 'good' : 'bad'}`;
    }
  };
  addEventListener('online', () => { updateNetwork(); syncQueue(); });
  addEventListener('offline', updateNetwork);
  updateNetwork();

  document.querySelectorAll('.toggle-password').forEach(button => button.addEventListener('click', () => {
    const input = button.parentElement.querySelector('input');
    input.type = input.type === 'password' ? 'text' : 'password';
  }));
  document.querySelector('form[action$="/logout"]')?.addEventListener('submit', () => {
    navigator.serviceWorker?.controller?.postMessage({type: 'CLEAR_PRIVATE_CACHE'});
  });

  function openDb() {
    return new Promise((resolve, reject) => {
      const request = indexedDB.open('fleet-offline-v1', 1);
      request.onupgradeneeded = () => request.result.createObjectStore('queue', {keyPath: 'key'});
      request.onsuccess = () => resolve(request.result);
      request.onerror = () => reject(request.error);
    });
  }
  async function saveQueue(item) {
    const db = await openDb();
    return new Promise((resolve, reject) => {
      const tx = db.transaction('queue', 'readwrite');
      tx.objectStore('queue').put(item);
      tx.oncomplete = resolve;
      tx.onerror = () => reject(tx.error);
    });
  }
  async function getQueue() {
    const db = await openDb();
    return new Promise((resolve, reject) => {
      const request = db.transaction('queue').objectStore('queue').getAll();
      request.onsuccess = () => resolve(request.result || []);
      request.onerror = () => reject(request.error);
    });
  }
  async function removeQueue(key) {
    const db = await openDb();
    return new Promise((resolve, reject) => {
      const tx = db.transaction('queue', 'readwrite');
      tx.objectStore('queue').delete(key);
      tx.oncomplete = resolve;
      tx.onerror = () => reject(tx.error);
    });
  }
  async function syncQueue() {
    if (!navigator.onLine || !document.querySelector('form[action$="/logout"]')) return;
    let queue;
    try { queue = await getQueue(); } catch (_) { return; }
    for (const item of queue) {
      try {
        const freshToken = document.querySelector('input[name="csrf"]')?.value || item.csrf;
        const response = await fetch(item.url, {
          method: 'POST', credentials: 'same-origin',
          headers: {'Content-Type': 'application/json', 'X-CSRF-Token': freshToken},
          body: JSON.stringify(item.payload)
        });
        if (!response.ok) break;
        await removeQueue(item.key);
        const message = document.getElementById('sync-message');
        if (message) message.textContent = 'Offline inspection synced successfully.';
      } catch (_) { break; }
    }
  }

  const form = document.querySelector('.inspection-form');
  if (!form) { syncQueue(); return; }
  const draftKey = `fleet-draft-${form.dataset.vehicle}`;
  const savedDraft = localStorage.getItem(draftKey);
  if (savedDraft) {
    try {
      const data = JSON.parse(savedDraft);
      for (const [name, value] of Object.entries(data)) {
        const element = form.elements[name];
        if (!element) continue;
        if (element instanceof RadioNodeList || (element.length && !element.type)) {
          [...element].forEach(option => { if (option.value === value) option.checked = true; });
        } else if (element.type === 'checkbox') {
          element.checked = value === element.value;
        } else {
          element.value = value;
        }
      }
    } catch (_) { localStorage.removeItem(draftKey); }
  }
  document.getElementById('save-draft')?.addEventListener('click', () => {
    const values = {};
    for (const [key, value] of new FormData(form).entries()) if (typeof value === 'string') values[key] = value;
    localStorage.setItem(draftKey, JSON.stringify(values));
    const message = document.getElementById('sync-message');
    if (message) message.textContent = 'Draft saved on this device.';
  });
  form.addEventListener('submit', async event => {
    if (navigator.onLine) { localStorage.removeItem(draftKey); return; }
    event.preventDefault();
    const values = new FormData(form), answers = {}, remarks = {};
    for (const [key, value] of values.entries()) {
      if (key.startsWith('item_')) answers[key.slice(5)] = value;
      if (key.startsWith('remark_')) remarks[key.slice(7)] = value;
    }
    const payload = {
      vehicle_id: Number(form.dataset.vehicle), start_km: values.get('start_km'),
      odometer: values.get('odometer'), notes: values.get('notes') || '', answers, remarks,
      driver_signature: values.get('driver_signature'), license_expiry: values.get('license_expiry'),
      attestation: values.get('attestation')
    };
    try {
      await saveQueue({key: `${payload.vehicle_id}-${form.dataset.day}`, url: form.dataset.syncUrl, csrf: values.get('csrf'), payload});
      localStorage.removeItem(draftKey);
      const message = document.getElementById('sync-message');
      if (message) message.textContent = 'Inspection saved on this device and will sync when connected. Photos require a connection.';
      form.querySelector('button[type="submit"]').disabled = true;
    } catch (_) {
      alert('Could not save offline data. Please reconnect and try again.');
    }
  });
  syncQueue();
})();
